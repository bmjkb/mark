package com.restapi.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.restapi.bean.Employee;
@Repository
public interface EmployeeRepo extends CrudRepository<Employee, Integer>{


}
