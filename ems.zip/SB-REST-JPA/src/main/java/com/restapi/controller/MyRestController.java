package com.restapi.controller;

import java.util.*;

import javax.ws.rs.PUT;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapi.bean.Employee;
import com.restapi.repo.EmployeeRepo;


@RestController
@RequestMapping("/EMS")
@CrossOrigin(origins="http://localhost:4200")
public class MyRestController {

	@Autowired
	EmployeeRepo repo;
	
	@GetMapping(path = "/Employees")
	public java.util.List<Employee> allEmployees() {
		ArrayList<Employee> list = new ArrayList<Employee>();
		Iterator<Employee> itr = repo.findAll().iterator();
		while(itr.hasNext()) {
			list.add(itr.next());
		}
		return list;

	}
	
	@GetMapping(path="/Employee/{id}")
	public Employee getEmployees(@PathVariable Integer id) {
		
		return repo.findById(id).get();

	}
	
	@PostMapping(path="/CreateEmployee")
	public void insertEmployee(@RequestBody Employee bean) {
		repo.save(bean);
	}
	
//	/* Another method for inserting values */
//	@PostMapping(path="/CreateEmployee/{id}/{name}/{salary}")
//	public void insertEmployee2(@PathVariable Employee bean) {
//		repo.save(bean);
//	}
	
	@PutMapping(path="/UpdateEmployee")
	public void updateEmployee(@RequestBody Employee bean) {
		repo.save(bean);
	}
	
	@DeleteMapping(path="/DeleteEmployee/{id}")
	public void deleteEmployee(@PathVariable Integer id) {
		repo.deleteById(id);
	}
	
	/*Another method of deleting the value*/
	
	@DeleteMapping(path="/DeleteEmployeeById")
	public void deleteEmployee2(Integer id) {
		repo.deleteById(id);
	}
}
