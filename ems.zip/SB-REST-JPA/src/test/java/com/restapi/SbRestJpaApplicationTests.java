package com.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbRestJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
