package com.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.login.model.Person;
import com.login.repo.MyRepo;

@RestController
@RequestMapping("/person")
@CrossOrigin(origins="http://localhost:4200")
public class MyController {
	
	@Autowired
	MyRepo repo;

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody Person info){
		System.out.println(info);
		Person person = repo.findByUserId(info.getUserId());
		if(person.getPassword().equals(info.getPassword()))	
				return ResponseEntity.ok(person);
		
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
	}
	@PostMapping(path="/signUp")
	public void signUp(@RequestBody Person bean) {
		repo.save(bean);
	}

	@PutMapping(path="/changePassword")
	public void changePassword(@RequestBody Person bean) {
		repo.changePassword(bean.getUserId(), bean.getPassword(), bean.getConfirm_Pass());
	}
}
