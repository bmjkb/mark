package com.login.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "person")
@AllArgsConstructor
@Data
@NoArgsConstructor
public class Person {

	@Id
	private String userId;
	private String password;
	private String confirm_Pass;

	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Person(String userId, String password, String confirm_Pass) {
		super();
		this.userId = userId;
		this.password = password;
		this.confirm_Pass = confirm_Pass;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirm_Pass() {
		return confirm_Pass;
	}

	public void setConfirm_Pass(String confirm_Pass) {
		this.confirm_Pass = confirm_Pass;
	}

}
