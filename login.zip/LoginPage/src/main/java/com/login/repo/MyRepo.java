package com.login.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.login.model.Person;

@Repository
public interface MyRepo extends CrudRepository<Person, String>{

	Person findByUserId(String userId);
	
	@Transactional
	@Modifying
	@Query(value="update person set password = :password, confirm_Pass = :confirm_Pass where user_id = :user_id",nativeQuery = true)
	public void changePassword(String user_id, String password, String confirm_Pass);
}
